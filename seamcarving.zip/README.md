#SeamCarver

In order to run this program, please read the README.md file

####Program Files
* main.py
* seamcarver.py

run by typing the following command

```$ python main.py INPUT_FILE_HERE.txt```

Once the process is finished it will output a file called 

```INPUT_FILE_HERE_trace.txt``` with the minimum seam information

##Development
Soon I will be able to support image inputs rather than just txt files. Check back soon for that feature!


